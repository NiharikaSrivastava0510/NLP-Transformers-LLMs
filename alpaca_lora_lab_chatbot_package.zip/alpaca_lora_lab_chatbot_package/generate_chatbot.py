# !/usr/bin/env python
# -*- coding: utf-8 -*-

######################################################################
#
# (c) Copyright University of Southampton, 2024
#
# Copyright in this software belongs to University of Southampton,
# Highfield, University Road, Southampton SO17 1BJ
#
# Created By : Stuart E. Middleton
# Created Date : 2024/04/02
# Project : Teaching
# Restriction: Content for internal use at University of Southampton only
# Dependancies: Code derived from alpaca-lora code Apache License 2.licence 0 https://github.com/tloen/alpaca-lora/blob/main/generate.py
#
######################################################################

import os, sys, codecs, json, math

#
# optional GPU memory managament to get more from limited cards
# https://pytorch.org/docs/stable/notes/cuda.html#memory-management
#
os.environ['PYTORCH_CUDA_ALLOC_CONF'] = 'garbage_collection_threshold:0.6,max_split_size_mb:256'
print( 'cuda PYTORCH_CUDA_ALLOC_CONF = ', os.environ['PYTORCH_CUDA_ALLOC_CONF'] )

import fire
import torch

import transformers
from peft import PeftModel
from transformers import GenerationConfig, LlamaForCausalLM, LlamaTokenizer

from utils.callbacks import Iteratorize, Stream
from utils.prompter import Prompter

def report_gpu_mem() :
	t = torch.cuda.get_device_properties(0).total_memory / 1000000000
	r = torch.cuda.memory_reserved(0) / 1000000000
	a = torch.cuda.memory_allocated(0) / 1000000000
	f = r-a
	print( 'cuda memory (free ', math.ceil(f), '; reserved ', math.ceil(r), '; allocated ', math.ceil(a), ')' )

if torch.cuda.is_available():
	torch.cuda.empty_cache()
	report_gpu_mem()
else:
	print('cuda not available')
	sys.exit(1)

print( 'device used = cuda' )

def main( base_model: str = "baffo32/decapoda-research-llama-7B-hf", prompt_template: str = '', test_file: str = '' ):
	base_model = base_model or os.environ.get("BASE_MODEL", "")
	assert (
		base_model
	), "Please specify a --base_model, e.g. --base_model='huggyllama/llama-7b'"

	print(
		f"Infer Alpaca-LoRA model with params:\n"
		f"base_model: {base_model}\n"
		f"test_file: {test_file}\n"
		)

	prompter = Prompter(prompt_template) # default alpaca prompt

	tokenizer = LlamaTokenizer.from_pretrained(base_model)
	tokenizer.pad_token_id = tokenizer.unk_token_id
	tokenizer.padding_side = "left"  # padding allows batched inference later
	print( 'pad token = unk token = ', tokenizer.unk_token_id )

	model = LlamaForCausalLM.from_pretrained(
		base_model,
		load_in_8bit=False,
		torch_dtype=torch.float16,
		device_map="auto",
	)

	model.eval()
	if torch.__version__ >= "2" and sys.platform != "win32":
		model = torch.compile(model)

	#############
	# ADD LAB SHAPE CODE HERE
	#############

	#
    # eval single input (slower but takes up less GPU memory)
	#
	def evaluate(
		instruction,
		input=None,
		temperature=0.1,
		top_p=0.75,
		top_k=40,
		num_beams=4,
		max_new_tokens=128,
		**kwargs,
	):
		prompt = prompter.generate_prompt(instruction, input)

		tokenized_input = tokenizer( prompt, return_tensors="pt" )

		encoded_sequence = tokenized_input["input_ids"].to("cuda")

		generation_config = GenerationConfig(
			temperature=temperature,
			top_p=top_p,
			top_k=top_k,
			num_beams=num_beams,
			**kwargs,
		)

		with torch.no_grad():
			generation_output = model.generate(
				input_ids=encoded_sequence,
				generation_config=generation_config,
				return_dict_in_generate=True,
				output_scores=True,
				max_new_tokens=max_new_tokens
			)

			seq = generation_output.sequences[0]
			output = tokenizer.decode(seq)

			del generation_output

		return output

	#
    # eval batch input (faster then single input but takes up more GPU memory)
	#
	def evaluate_batch(
		list_instructions,
		list_inputs=None,
		temperature=0.1,
		top_p=0.75,
		top_k=40,
		num_beams=4,
		max_new_tokens=128,
		**kwargs,
	):
		prompts = []
		for i in range(len(list_instructions)) :
			if list_inputs != None :
				prompts.append( prompter.generate_prompt(list_instructions[i], list_inputs[i]) )
			else :
				prompts.append( prompter.generate_prompt(list_instructions[i], None) )

		tokenized_input_batch = tokenizer( prompts, padding=True, truncation=True, return_tensors="pt" )

		encoded_sequence = tokenized_input_batch['input_ids'].to("cuda")

		generation_config = GenerationConfig(
			temperature=temperature,
			top_p=top_p,
			top_k=top_k,
			num_beams=num_beams,
			max_new_tokens=max_new_tokens,
			**kwargs,
		)

		with torch.no_grad():
			batch_output = model.generate(
				input_ids = encoded_sequence,
				generation_config=generation_config,
				return_dict_in_generate=True,
				output_scores=True,
				max_new_tokens=max_new_tokens
			)

			list_output = []
			for seq in batch_output.sequences :
				output = tokenizer.decode(seq)
				list_output.append( output )

			del batch_output

		return list_output

	#
	# infer one by one (less GPU mem needed, but slower)
	#

	for prompt in [
		"Tell me about alpacas.",
		"Tell me about the president of Mexico in 2019.",
		"Tell me about the king of France in 2019.",
		#"List all Canadian provinces in alphabetical order.",
		#"Write a Python program that prints the first 10 Fibonacci numbers.",
		#"Write a program that prints the numbers from 1 to 100. But for multiples of three print 'Fizz' instead of the number and for the multiples of five print 'Buzz'. For numbers which are multiples of both three and five print 'FizzBuzz'.",  # noqa: E501
		#"Tell me five words that rhyme with 'shock'.",
		#"Translate the sentence 'I have no mouth but I must scream' into Spanish.",
		#"Count up from 1 to 500.",
	]:
		print('Individual Instruction:', prompt)

		str_response = evaluate(
			instruction = prompt,
			input = None,
			temperature = 0.1,		# 0 .. 1
			top_p = 0.75,			# 0 .. 1
			top_k = 40,				# 0 .. 100
			num_beams = 4,			# 1 .. 4
			max_new_tokens = 128,	# 1 .. 2000 (max generated response size)
			)

		#report_gpu_mem()

		# confirm output is OK for this model
		# it uses the default alpaca template so should generate ### Response: then answer
		# if cutoff too low this might get truncated also
		if not '### Response:' in str_response :
			print('Bad response:', str_response)
			return

		str_output = prompter.get_response(str_response)
		# remove eos to get answer
		str_output = str_output.strip('</s>')

		print('Inferred Answer:', str_output)

	#
	# infer as a batch (more GPU mem needed, but faster)
	# does not work on the ECS lab machines with 8G GPU RAM
	#

	'''

	list_instructions = [
		"Tell me about alpacas.",
		"Tell me about the president of Mexico in 2019.",
		"Tell me about the king of France in 2019.",
	]
	print('\n\nBatch Instruction:', list_instructions
	)
	batch_response = evaluate_batch(
		list_instructions = list_instructions,
		input = None,
		temperature = 0.1,		# 0 .. 1
		top_p = 0.75,			# 0 .. 1
		top_k = 40,				# 0 .. 100
		num_beams = 4,			# 1 .. 4
		max_new_tokens = 128,	# 1 .. 2000 (max generated response size)
		)

	for i in range(len(batch_response)) :
		str_output = prompter.get_response(batch_response[i])
		# remove eos to get answer
		str_output = str_output.strip('</s>')
		print('Inferred Answer:', str_output)

	del batch_response

	'''

if __name__ == "__main__":
	fire.Fire(main)
